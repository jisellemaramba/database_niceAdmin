<article>
    <h1>Paris</h1>
    <p>Paris is the capital city of France. It is one of the most iconic cities in the world, known for its art, fashion, gastronomy, and culture.</p>
    <p>Located along the River Seine, Paris has a rich history dating back over 2,000 years. It is home to famous landmarks such as the Eiffel Tower, the Louvre Museum, and Notre-Dame Cathedral.</p>
</article>
